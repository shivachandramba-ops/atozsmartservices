# A To Z Smart Services — Website

A premium, fully static, mobile-first website for **A To Z Smart Services**, a home repair and maintenance company. Built with plain HTML5, CSS3 and vanilla JavaScript (plus Bootstrap 5, AOS, Font Awesome and Swiper.js for polish). No backend, database or CMS is required — the entire site can be hosted on any static file host (Netlify, Vercel, GitHub Pages, cPanel, S3, etc.).

## Live domain
`www.atozsmartservices.com`

## Folder structure

```
AtoZSmartServices/
├── index.html          Home page
├── services.html        Services page (19 services, filterable)
├── about.html            About Us page
├── contact.html          Contact Us page (WhatsApp-integrated form)
├── css/
│   ├── style.css         Design tokens, layout, components
│   ├── responsive.css     Media queries / mobile-first breakpoints
│   └── animations.css    Keyframes & motion utilities
├── js/
│   ├── script.js          Preloader, navbar, counters, FAQ, sliders
│   ├── validation.js       Contact form validation
│   └── whatsapp.js         WhatsApp Click-to-Chat link builder
├── images/                Favicon & any future image assets
├── icons/                 Reserved for custom icon assets
├── assets/                Reserved for misc. static assets
└── README.md
```

## Design system

- **Colors:** deep navy (`#0A1428`), gold accent (`#C9A227`), teal accent (`#0E9594`), warm off-white background (`#F6F7FA`).
- **Typography:** Bricolage Grotesque (display), Inter (body), Space Grotesk (numerals/utility) — loaded from Google Fonts.
- **Signature element:** the "Coverage Dial" in the hero — a rotating glassmorphic ring of service icons around an A2Z core, symbolising full A-to-Z service coverage.
- **Effects:** glassmorphism panels, soft gradients, rounded cards, scroll-triggered animations (AOS), animated stat counters, sticky/transparent navbar, marquee trust strip.

## WhatsApp booking

Every "Book Now" button, the floating WhatsApp button, and the contact form submit button open WhatsApp via the Click-to-Chat URL format:

```
https://wa.me/917702434892?text=<url-encoded message>
```

- Buttons with `data-whatsapp-service="Service Name"` pre-fill a booking message for that specific service.
- Buttons with `data-whatsapp-general` open a general enquiry message.
- The contact form (`contact.html`) validates all required fields with `js/validation.js`, then builds a full message (name, phone, service, message) and opens WhatsApp with `js/whatsapp.js`.

To change the WhatsApp number, update the `WHATSAPP_NUMBER` constant in `js/whatsapp.js` (and the visible phone number across the HTML files).

## Third-party libraries (via CDN)

- [Bootstrap 5.3.3](https://getbootstrap.com/) — grid & base utility resets
- [AOS 2.3.4](https://michalsnik.github.io/aos/) — scroll animations
- [Swiper 11](https://swiperjs.com/) — testimonials carousel
- [Font Awesome 6.5.1](https://fontawesome.com/) — iconography
- [Google Fonts](https://fonts.google.com/) — Bricolage Grotesque, Inter, Space Grotesk

No React, Vue, Angular, PHP, Node.js, Laravel or database is used anywhere in this project.

## Customisation notes

- Service cards currently use icon-based image placeholders (gradient tiles with Font Awesome icons) instead of photography, so the site works fully offline with zero broken image links. Swap the `.service-thumb` / `.about-visual` / `.team-photo` divs for real photography whenever available.
- Pricing shown on service cards is indicative — update figures in `services.html` and `index.html` to match your actual price list.
- The embedded Google Map on `contact.html` points to a general area query string; replace the `src` with your exact business location URL once available.

## Accessibility & performance

- Semantic HTML5 landmarks (`header`, `main`, `footer`, `nav`) throughout.
- Visible keyboard focus states on all interactive elements.
- `prefers-reduced-motion` is respected — animations are disabled for users who request it.
- Mobile-first CSS with breakpoints at 1200px, 991px, 767px and 575px.
- All images/icons are vector or CSS-based, keeping page weight low and load times fast.
