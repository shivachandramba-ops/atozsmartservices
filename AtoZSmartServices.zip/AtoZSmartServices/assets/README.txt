Reserved for miscellaneous static assets.
