Reserved for custom icon assets.
