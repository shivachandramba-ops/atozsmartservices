/* ==========================================================================
   A TO Z SMART SERVICES — WHATSAPP INTEGRATION
   Builds WhatsApp Click-to-Chat links for "Book Now" buttons and the
   contact form. No backend required — everything happens client-side.
   ========================================================================== */

(function () {
  "use strict";

  // Company WhatsApp number in international format (no + or spaces)
  var WHATSAPP_NUMBER = "917702434892";

  /**
   * Opens WhatsApp with a pre-filled message.
   * @param {string} message - Plain text message to pre-fill.
   */
  function openWhatsApp(message) {
    var encoded = encodeURIComponent(message);
    var url = "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encoded;
    window.open(url, "_blank", "noopener");
  }

  /**
   * Builds the standard booking message for a single service.
   * @param {string} serviceName
   */
  function buildServiceMessage(serviceName) {
    return (
      "Hello A To Z Smart Services,\n" +
      "I would like to book a service.\n\n" +
      "Service: " + serviceName + "\n" +
      "Please contact me."
    );
  }

  /**
   * Builds the full message from contact-form field values.
   */
  function buildFormMessage(fields) {
    return (
      "Hello A To Z Smart Services,\n" +
      "I would like to book a service.\n\n" +
      "Name: " + fields.name + "\n" +
      "Phone: " + fields.phone + "\n" +
      "Service: " + fields.service + "\n" +
      "Message: " + (fields.message || "-") + "\n\n" +
      "Please contact me."
    );
  }

  // Wire up every "Book Now" button that carries a data-service attribute
  document.addEventListener("DOMContentLoaded", function () {
    var bookButtons = document.querySelectorAll("[data-whatsapp-service]");
    bookButtons.forEach(function (btn) {
      btn.addEventListener("click", function (e) {
        e.preventDefault();
        var serviceName = btn.getAttribute("data-whatsapp-service") || "General Service";
        openWhatsApp(buildServiceMessage(serviceName));
      });
    });

    // Generic floating WhatsApp buttons (no specific service context)
    var generalButtons = document.querySelectorAll("[data-whatsapp-general]");
    generalButtons.forEach(function (btn) {
      btn.addEventListener("click", function (e) {
        e.preventDefault();
        openWhatsApp(
          "Hello A To Z Smart Services,\nI would like to know more about your services.\nPlease contact me."
        );
      });
    });
  });

  // Expose helpers globally so validation.js can trigger the form submission flow
  window.A2Z_WHATSAPP = {
    open: openWhatsApp,
    buildFormMessage: buildFormMessage,
    number: WHATSAPP_NUMBER
  };
})();
