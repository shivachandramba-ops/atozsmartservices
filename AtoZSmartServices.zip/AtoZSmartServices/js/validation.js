/* ==========================================================================
   A TO Z SMART SERVICES — CONTACT FORM VALIDATION
   Validates the contact form fields client-side, then triggers the
   WhatsApp click-to-chat flow (see whatsapp.js) with the collected data.
   ========================================================================== */

(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    var form = document.getElementById("contactForm");
    if (!form) return;

    var nameField = document.getElementById("fullName");
    var phoneField = document.getElementById("mobileNumber");
    var emailField = document.getElementById("email");
    var serviceField = document.getElementById("selectService");
    var messageField = document.getElementById("message");
    var successBox = document.getElementById("formSuccess");

    var phonePattern = /^[6-9]\d{9}$/; // Indian 10-digit mobile numbers
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    function setError(field, hasError) {
      var group = field.closest(".form-group");
      if (!group) return;
      group.classList.toggle("invalid", hasError);
    }

    function validateName() {
      var value = nameField.value.trim();
      var valid = value.length >= 3;
      setError(nameField, !valid);
      return valid;
    }

    function validatePhone() {
      var value = phoneField.value.trim();
      var valid = phonePattern.test(value);
      setError(phoneField, !valid);
      return valid;
    }

    function validateEmail() {
      var value = emailField.value.trim();
      // Email is optional, but if provided it must be well-formed
      var valid = value === "" || emailPattern.test(value);
      setError(emailField, !valid);
      return valid;
    }

    function validateService() {
      var valid = serviceField.value !== "";
      setError(serviceField, !valid);
      return valid;
    }

    // Live validation as the user types / selects
    nameField.addEventListener("input", validateName);
    phoneField.addEventListener("input", validatePhone);
    emailField.addEventListener("input", validateEmail);
    serviceField.addEventListener("change", validateService);

    form.addEventListener("submit", function (e) {
      e.preventDefault();

      var isNameValid = validateName();
      var isPhoneValid = validatePhone();
      var isEmailValid = validateEmail();
      var isServiceValid = validateService();

      if (!isNameValid || !isPhoneValid || !isEmailValid || !isServiceValid) {
        var firstInvalid = form.querySelector(".form-group.invalid .form-control");
        if (firstInvalid) {
          firstInvalid.focus();
          firstInvalid.scrollIntoView({ behavior: "smooth", block: "center" });
        }
        return;
      }

      var fields = {
        name: nameField.value.trim(),
        phone: phoneField.value.trim(),
        service: serviceField.options[serviceField.selectedIndex].text,
        message: messageField.value.trim()
      };

      // Build and open the WhatsApp chat using the shared helper
      if (window.A2Z_WHATSAPP) {
        window.A2Z_WHATSAPP.open(window.A2Z_WHATSAPP.buildFormMessage(fields));
      }

      // Show a friendly success message and reset the form
      if (successBox) {
        successBox.classList.add("show");
        setTimeout(function () {
          successBox.classList.remove("show");
        }, 6000);
      }
      form.reset();
    });
  });
})();
