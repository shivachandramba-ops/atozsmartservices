/* ==========================================================================
   A TO Z SMART SERVICES — CORE SCRIPT
   Preloader, navbar behaviour, animated counters, FAQ accordion,
   testimonial slider, service filters, scroll-to-top.
   ========================================================================== */

(function () {
  "use strict";

  /* ---------------------------------------------------
     1. PRELOADER
  --------------------------------------------------- */
  window.addEventListener("load", function () {
    var preloader = document.getElementById("preloader");
    if (preloader) {
      setTimeout(function () {
        preloader.classList.add("loaded");
      }, 300);
    }
    // Initialise AOS once page assets are ready
    if (window.AOS) {
      AOS.init({
        duration: 800,
        easing: "ease-out-cubic",
        once: true,
        offset: 60
      });
    }
  });

  /* ---------------------------------------------------
     2. NAVBAR — scroll state + mobile toggle
  --------------------------------------------------- */
  var navbar = document.getElementById("mainNavbar");
  var navToggle = document.getElementById("navToggle");
  var navLinks = document.getElementById("navLinks");

  function handleNavScroll() {
    if (!navbar) return;
    if (window.scrollY > 40) {
      navbar.classList.add("scrolled");
    } else {
      navbar.classList.remove("scrolled");
    }
  }
  handleNavScroll();
  window.addEventListener("scroll", handleNavScroll);

  if (navToggle && navLinks) {
    navToggle.addEventListener("click", function () {
      navLinks.classList.toggle("open");
      var icon = navToggle.querySelector("i");
      if (icon) {
        icon.classList.toggle("fa-bars");
        icon.classList.toggle("fa-xmark");
      }
    });

    // Close mobile menu when a link is tapped
    navLinks.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        navLinks.classList.remove("open");
        var icon = navToggle.querySelector("i");
        if (icon) {
          icon.classList.add("fa-bars");
          icon.classList.remove("fa-xmark");
        }
      });
    });
  }

  /* ---------------------------------------------------
     3. BACK TO TOP
  --------------------------------------------------- */
  var backToTop = document.getElementById("backToTop");
  if (backToTop) {
    window.addEventListener("scroll", function () {
      if (window.scrollY > 500) {
        backToTop.classList.add("show");
      } else {
        backToTop.classList.remove("show");
      }
    });
    backToTop.addEventListener("click", function () {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  /* ---------------------------------------------------
     4. ANIMATED COUNTERS (stats band)
  --------------------------------------------------- */
  var counters = document.querySelectorAll("[data-counter]");
  if (counters.length) {
    var counterObserver = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            animateCounter(entry.target);
            counterObserver.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.5 }
    );
    counters.forEach(function (el) {
      counterObserver.observe(el);
    });
  }

  function animateCounter(el) {
    var target = parseInt(el.getAttribute("data-counter"), 10) || 0;
    var duration = 1600;
    var startTime = null;

    function step(timestamp) {
      if (!startTime) startTime = timestamp;
      var progress = Math.min((timestamp - startTime) / duration, 1);
      var eased = 1 - Math.pow(1 - progress, 3); // ease-out-cubic
      var value = Math.floor(eased * target);
      el.textContent = value.toLocaleString("en-IN");
      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        el.textContent = target.toLocaleString("en-IN");
      }
    }
    requestAnimationFrame(step);
  }

  /* ---------------------------------------------------
     5. FAQ ACCORDION
  --------------------------------------------------- */
  var faqItems = document.querySelectorAll(".faq-item");
  faqItems.forEach(function (item) {
    var question = item.querySelector(".faq-q");
    var answer = item.querySelector(".faq-a");
    if (!question || !answer) return;

    question.addEventListener("click", function () {
      var isOpen = item.classList.contains("open");

      // Close all other items (single-open accordion)
      faqItems.forEach(function (other) {
        other.classList.remove("open");
        var otherAnswer = other.querySelector(".faq-a");
        if (otherAnswer) otherAnswer.style.maxHeight = null;
      });

      if (!isOpen) {
        item.classList.add("open");
        answer.style.maxHeight = answer.scrollHeight + "px";
      }
    });
  });

  /* ---------------------------------------------------
     6. SERVICE CATEGORY FILTER (Services page)
  --------------------------------------------------- */
  var filterButtons = document.querySelectorAll("[data-filter]");
  var serviceCards = document.querySelectorAll("[data-category]");

  if (filterButtons.length && serviceCards.length) {
    filterButtons.forEach(function (btn) {
      btn.addEventListener("click", function () {
        filterButtons.forEach(function (b) {
          b.classList.remove("active");
        });
        btn.classList.add("active");

        var filter = btn.getAttribute("data-filter");

        serviceCards.forEach(function (card) {
          var category = card.getAttribute("data-category");
          var show = filter === "all" || filter === category;
          card.style.display = show ? "" : "none";
        });
      });
    });
  }

  /* ---------------------------------------------------
     7. TESTIMONIAL SWIPER
  --------------------------------------------------- */
  if (window.Swiper) {
    var testimonialSwiper = document.querySelector(".testimonial-swiper");
    if (testimonialSwiper) {
      new Swiper(".testimonial-swiper", {
        loop: true,
        autoplay: { delay: 4500, disableOnInteraction: false },
        spaceBetween: 24,
        pagination: {
          el: ".swiper-pagination",
          clickable: true
        },
        breakpoints: {
          0: { slidesPerView: 1 },
          768: { slidesPerView: 2 },
          1100: { slidesPerView: 3 }
        }
      });
    }
  }

  /* ---------------------------------------------------
     8. CURRENT YEAR IN FOOTER
  --------------------------------------------------- */
  var yearEls = document.querySelectorAll("[data-year]");
  yearEls.forEach(function (el) {
    el.textContent = new Date().getFullYear();
  });

  /* ---------------------------------------------------
     9. SET ACTIVE NAV LINK BASED ON CURRENT PAGE
  --------------------------------------------------- */
  var currentPage = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".nav-links a").forEach(function (link) {
    var href = link.getAttribute("href");
    if (href === currentPage || (currentPage === "" && href === "index.html")) {
      link.classList.add("active");
    }
  });
})();
